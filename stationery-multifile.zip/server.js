const express = require("express");
const fs = require("fs");
const app = express();

app.use(express.json());
app.use(express.static("public"));

let data = require("./data.json");

app.get("/products", (req,res)=>res.json(data.products));

app.post("/add",(req,res)=>{
 data.products.push(req.body);
 fs.writeFileSync("data.json", JSON.stringify(data));
 res.send("Added");
});

app.listen(3000);